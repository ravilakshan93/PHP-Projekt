<div class="ottWrapper">
    <h2 class="titel3">OTT - Over-The-Top (media service) </h2>
        <p id="ottText">
            OTT steht für Over-the-top media service und ist ein Mediendienst, der den Zuschauern direkt über das Internet angeboten wird. OTT umgeht Kabel-, Rundfunk- und Satellitenfernsehplattformen, die Arten von Unternehmen, die traditionell als Kontrolleure oder Vertreiber solcher Inhalte fungieren. Der Zugriff auf Over-the-Top-Dienste erfolgt in der Regel über Websites auf PCs sowie über Apps auf mobilen Geräten (wie Smartphones und Tablets), digitalen Mediaplayern (einschließlich Videospielkonsolen) oder Fernsehern mit integrierten Smart-TV-Plattformen. 
        </p>

        <h2 class="titel3">Die beliebtesten OTT-Plattformen, die täglich genutzt:</h2>


    <div class="ottInfo">
        <div class="ott1">
                <p id="ottText1">Netflix</p>
            
            <img id="unten" src="./bilder/netflix.png" alt="Netflix" width="100" height="90">
         </div>


        <div class="ott2"> 
                <p id="ottText1">Amazon Prime</p>
            <img id="unten" src="./bilder/amazonPrime.png" alt="Amazon Prime" width="100" height="90">
        </div>

        <div class="ott1">
                <p id="ottText1">Disney+</p>
            
            <img  id="unten" id="unten" src="./bilder/Disney.png" alt="Disney+" width="100" height="90">
         </div>

        <div class="ott2"> 
                <p id="ottText1">Hulu</p>
            
            <img  id="unten" src="./bilder/hulu.png" alt="Hulu" width="100" height="90">
        </div>
</div>




