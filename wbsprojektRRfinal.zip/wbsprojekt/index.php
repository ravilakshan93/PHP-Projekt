<?php
session_start();
//setlocale(LC_ALL,"de_DE","deu_deu","german");
require_once "inc/myDatenbank.inc.php";
require_once 'inc/functionen.inc.php';


//If statement für falsche Benutzer daten
if(isset($_SESSION['nachricht'])) {
    $nachricht = $_SESSION['nachricht'];
    unset($_SESSION['nachricht']);
}

$site = "";
if(isset($_GET["page"]))
    {
        $site = $_GET["page"];    
    }
    else
    {
        $site = "home";
    }


//$site = $_GET["site"] ?? '';
require_once "inc/header.inc.php";

//echo 'test ###';
//print_r($site);


//switch Funtion für navigieren
switch($site){
    
    case "home" : include "inc/home.inc.php"; break;
    case "cinema" : include "inc/cinema.inc.php"; break;
    case "ott" : include "inc/ott.inc.php"; break;
    case "kontakt" : include "inc/kontakt.inc.php"; break;
    case "bewertung" : include "inc/bewertung.inc.php"; break;
    case "new" : include "inc/newMember.inc.php"; break;
    case "myKonto" : include "inc/myKonto.inc.php"; break;
    case "impressum" : include "inc/impressum.inc.php"; break;
    default:include "inc/home.inc.php"; break;
}

require_once "inc/footer.inc.php";


?>


