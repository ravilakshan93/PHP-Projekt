</main>/ <!--Ende der main element von der index seite(home)-->
    </div> <!--Ende der container div von der von der index seite(home)-->

<footer>
    <h3>&copy; WBS PHP Abschluss Projekt - Oktober 2021 - Ravilakshan Ravikumar</h3>
        <div class="footerNav">
            <nav id="nav1">
                <ul class="footerNavi">
                    <li><a href="">Impressum</a></li>
                </ul>
            <nav>
        </div>
</footer>
    
<!--Ende der div, body, html von header file der index seite(home)-->
</div> 
</body>
</html>
    