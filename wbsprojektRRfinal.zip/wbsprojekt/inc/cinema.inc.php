<div id="cinemaWrapper">
    <h2 class="titel2">Was ist Cinema</h2>
        <p id="cinemaText">
            Kino ist ein Film, in dem Filme für das Publikum auf einer großen Leinwand abgespielt werden. Früher gab es eine ähnliche Art von Kino, in dem die Leute das Theater nutzen, um mit den Puppen aufzutreten. Nach vielen Jahren hat sich das Konzept stark und international geändert, wo die Leute die Möglichkeit haben, jedes Kino zu besuchen und ihre Lieblingsfilme auf der großen Leinwand zu sehen.
        </p>
    <div id="textWrapper">
        <div id="text1">
            <h2>Schwarz-Weiß film Seit 1930 <span id="mehr">(Klick für mehr info)</span></h2>
                <div>
                    <p>
                        Kino ist ein Film, in dem Filme für das Publikum auf einer großen Leinwand abgespielt werden. Früher gab es eine ähnliche Art von Kino, in dem die Leute das Theater nutzen, um mit den Puppen aufzutreten. Nach vielen Jahren hat sich das Konzept stark und international geändert, wo die Leute die Möglichkeit haben, jedes Kino zu besuchen und ihre Lieblingsfilme auf der großen Leinwand zu sehen.
                    </p>   
                </div>
                <img class="cineBild" src="./bilder/bw_bild.jpg" alt="Schwarzweiß Film" width="960" height="640">
        </div>

        <div id="text1">
            <h2>Farbfilm Seit<span id="mehr">(Klick für mehr info)</span> </h2>
                <div>
                    <p>
                        Kino ist ein Film, in dem Filme für das Publikum auf einer großen Leinwand abgespielt werden. Früher gab es eine ähnliche Art von Kino, in dem die Leute das Theater nutzen, um mit den Puppen aufzutreten. Nach vielen Jahren hat sich das Konzept stark und international geändert, wo die Leute die Möglichkeit haben, jedes Kino zu besuchen und ihre Lieblingsfilme auf der großen Leinwand zu sehen.
                    </p>
                </div>
                <img class="cineBild" src="./bilder/farb_bild.png" alt="Farbfilm" width="960" height="640">
        </div>
    </div>

    <div id="textWrapper">
        <div id="text1">
            <h2>3D Film Seit <span id="mehr">(Klick für mehr info)</span></h2>
                <div>
                    <p>
                        Kino ist ein Film, in dem Filme für das Publikum auf einer großen Leinwand abgespielt werden. Früher gab es eine ähnliche Art von Kino, in dem die Leute das Theater nutzen, um mit den Puppen aufzutreten. Nach vielen Jahren hat sich das Konzept stark und international geändert, wo die Leute die Möglichkeit haben, jedes Kino zu besuchen und ihre Lieblingsfilme auf der großen Leinwand zu sehen.
                    </p>   
                </div>
                <img class="cineBild" src="./bilder/3d_bild.png" alt="Schwarzweiß Film" width="960" height="640">
        </div>

        <div id="text1">
            <h2>Animated Film Seit<span id="mehr">(Klick für mehr info)</span> </h2>
                <div>
                    <p>
                        Kino ist ein Film, in dem Filme für das Publikum auf einer großen Leinwand abgespielt werden. Früher gab es eine ähnliche Art von Kino, in dem die Leute das Theater nutzen, um mit den Puppen aufzutreten. Nach vielen Jahren hat sich das Konzept stark und international geändert, wo die Leute die Möglichkeit haben, jedes Kino zu besuchen und ihre Lieblingsfilme auf der großen Leinwand zu sehen.
                    </p>
                </div>
                <img class="cineBild" src="./bilder/animated_bild.png" alt="Farbfilm" width="960" height="640">
        </div>
    </div>
</div>