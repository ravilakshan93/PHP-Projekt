<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP-Projekt</title>
    <link rel="stylesheet" href="./fontawesome/css/all.css" />
    <style>
        <?php
            include "style.css";//Styling für die Webseite
        ?>  
    </style>
    <!--Javascript/JQUERY für die Projekt-->
    <script src="jQuery3.6.0/jquery-3.6.0.js" type="text/javascript" ></script>
    <script src="jQuery3.6.0/jquery.validate.js"></script>
    <script src="index.js" type="text/javascript" async></script>
</head>

<body>
    <!--Main -->
    <div id="wrapper">
        <header>
            <img id="logo" src="./bilder/logo.jpg" alt="topLogo" width="612" height="490">
                <h1 class="header1">Cinema & OTT
                    <span class="tagLine">Anytime & Anywhere</span>
                </h1>       
                <div id="socialMedia">
                    <img id="social" src="./bilder/menu-icon_sm.png" alt="socialMedia top" width="70" height="42">
                        <i class="fab fa-facebook"></i>
                        <i class="fab fa-facebook" style="color: #4267B2"></i>
                        <i class="fab fa-twitter" style="color: #1DA1F2"></i>
                        <i class="fab fa-instagram" style="color: #8a3ab9"></i>
                        <i class="fab fa-youtube" style="color: #FF0000"></i>
                        <i class="fab fa-linkedin" style="color: #0077b5"></i>
                </div>
        </header>

<!--Slider-->
    <div id="slideShow">
        <figure>
            <img class="slideBild" src="./bilder/sliderBild1.jpg" alt="myslide1">
            <img class="slideBild" src="./bilder/sliderBild2.jpg" alt="myslide2">
            <img class="slideBild" src="./bilder/sliderBild3.jpg" alt="myslide3">
            <img class="slideBild" src="./bilder/sliderBild4.jpg" alt="myslide4">
            <img class="slideBild" src="./bilder/sliderBild1.jpg" alt="myslide1">
        </figure>
    </div>
<!--Navi-->
    <div id="container">
        <nav class="navi">
            <ul>
                <li class="<?php empty($site) ? 'active' : ""; ?>"><a href="index.php">Home</a></li>
                <li class="<?php echo ($site === "cinema") ? 'active' : "";?>"><a href="index.php?page=cinema">Cinema</a></li>
                <li class="<?php echo ($site === "ott") ? 'active' : ""; ?>"><a href="index.php?page=ott">OTT</a></li>
                <li class="<?php echo ($site === "kontakt") ? 'active' : "";?>"><a href="index.php?page=kontakt">Kontakt</a></li>
                <li class="<?php echo ($site === "bewertung") ? 'active' : ""; ?>"><a href="index.php?page=bewertung">Filmbewertung</a></li>
            </ul>
                <!--PHP für den anmeldung zur Datenbank-->
                <?php   if(isset($nachricht)):?>
                        <p id="message"> <?=$nachricht?> </p>
                    <?php endif; ?>
                    <?php
                        if(istAngemeldet() ) 
                    {
                        require_once "inc/member_page.inc.php";
                    }
                    else
                    {
	                    require_once "./index.php";
                    }
                ?>
            </nav>
 <main>