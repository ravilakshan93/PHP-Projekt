"use strict";
//console.log("Hallo");  Zum testing

/******Sozial Media an den Header******/ 
$(document).ready(function(){
$("#socialMedia i").hide();

$("#socialMedia img").click(function(){
	$("i").next().animate({
		"opacity":"toggle",
		"height":"toggle"
	},1000);
});

/******Cinema Seite Toggle funktion******/ 
	$("#text1 div p").css({
		"background-color":"#000",
		"margin-bottom":"2px"
	});
	//------------
	$("#text1 div").hide();
    $("#text1 h2").click(function(){
		$(this).next().animate({
			"opacity":"toggle",
			"height":"toggle",
		},1000);
	});

});

/******Kontakt Formular Validiereung******/ 

$(document).ready(function(){
	let ausgabe = "";
$("#form").validate({
	rules: {
		nachname: {
			required: true,
			minlength: 3,
			maxlength: 20
		},
		vorname: {
			required: true,
			minlength: 3,
			maxlength: 20
		},
		ort: {
			required: true,
		},
		str: {
			required: true,
		},
		plz: {
			required: true,
			digits: true,
			rangelength: [5,5]
		},
		email:{
			required: true,
			email: true
		},
		tel:{
			required: true,
			digits: true,
			rangelength: [9, 13]
		}
	},

	messages: {
		nachname: {
			required: "Bitte geben Sie Ihre Nachname ein!", 
		    minlength: "Nachname soll mindestens 3 Zeichen haben",
      		maxlength: "Nachname soll maximal 20 Zeichen haben"
		},
		vorname: {
			required: "Bitte geben Sie Ihre Vorname ein!", 
		    minlength: "Vorname soll mindestens 3 Zeichen haben",
      		maxlength: "Vorname soll maximal 20 Zeichen haben"
		},
		geb: {
			required: "Bitte Geburtstag eingeben", 
			
		},
		ort: {
			required: "Bitte geben Sie Ihre Ort ein", 
		},
		str: {
			required: "Bitte geben Sie Ihre Straße ein", 
		},
		plz: {
			required: "Bitte geben Sie Ihre PLZ ein", 
			digits: "Keine Buchstaben sind erlaubt, nur Zahlen erforderlich",
			rangelength: "Nur 5 stellige PLZ ist erlaubt"
		},
		email: {
			required: "Bitte geben Sie Ihre E-Mail ein",
			email: "Bitte geben Sie einen gültigen E-Mail ein. Muster für E-Mail: mustermann@test.de"
		},
		tel: {
			required: "Bitte geben Sie Ihre Telefon Nr ein", 
			digits:"Keine Buchstaben sind erlaubt, nur Zahlen erforderlich",
			rangelength: "Ihre Telefon Nr sollte zwischen 9 und 13 Zeichen sein"
		},
	}
		
	});
	
	$("#form").submit(function(e){
		e.preventDefault();
		//ausgabe = document.getElementById("ausgabe").innerHTML = "Vielen Dank";
		
	});


});





