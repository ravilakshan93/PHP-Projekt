-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 25. Okt 2021 um 18:27
-- Server-Version: 10.4.6-MariaDB
-- PHP-Version: 7.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `wbsprojekt`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `members`
--

CREATE TABLE `members` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `vorname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `passwort` varchar(255) NOT NULL,
  `lieblings_filme` varchar(255) NOT NULL,
  `lieblings_Schauspieler_in` varchar(255) NOT NULL,
  `kino_oder_ott` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `members`
--

INSERT INTO `members` (`id`, `name`, `vorname`, `email`, `passwort`, `lieblings_filme`, `lieblings_Schauspieler_in`, `kino_oder_ott`) VALUES
(1, 'Mustermann', 'Max', 'max@gmail.com', '$2a$12$oLJE5hancb33MBISkfduH.6FrLWBthirM2fvxVgmIq0zQKGuRxxZi', 'Avengers Teil 1 und 2', 'Tom Cruise', 'Kino'),
(2, 'Keller', 'Patrick', 'patrick@gmail.com', '$2a$12$P/jcaUjIcmxHNaTk29GySu/jlRTQmvvR3EY/iqjVu/0XtS6o/.Biq', 'Conjuring und Annabelle', 'Patrick Wilson, Tom Cruise und Robert Downey', 'OTT'),
(3, 'Mettmann', 'Markus', 'markus@gmail.de', '$2a$12$jDyJuI2WKl/9HhrG5aJnXOAhlWhfXwjKscc4RvXHLMoKolFgKeBkK', 'Krimi und Thriller filme', 'Leonardo DiCaprio', 'OTT'),
(4, 'Hansel', 'Lisa', 'lisa@hotmail.de', '$2a$12$T8SOhmxW0meLNKHblm7xQ.AMeKJJscuLGFbVgyWwcVhDfzNXNFTBK', 'Haus des Geldes serie (auf Netflix) und Action Filme', 'Lin Shaye', 'OTT '),
(5, 'Vormann', 'Klaus', 'klaus123@gmail.de', '$2y$10$LO38K32wzSKOjAOTK2CtjeRqvnAkIGzHAJD0Tl0Q.BmSNsVwVQRZu', '', '', 'Bite Auswählen'),
(6, 'Schluss', 'Kevin', 'kevin@12gmail.de', '$2y$10$NrTRH5musQOhi9y5lkZLFOzh/9l8ldLSBAET0jq/M/L.ABLnCNEp.', 'Test', 'Test', 'Kino'),
(7, 'herz', 'has', 'herz123@gmail.de', '$2y$10$/RMahQrDHKIBRS4rFgbwf.73b6Ryp4M4jThtomDwEG/IW9WFVWl26', '', '', 'Bite Auswählen'),
(8, 'Neuer', 'user', 'user@test.de', '$2y$10$AHpw8gOUbkLNREElEtEYqujkF4mFFxG6A57iMYU.eHJjlhzvsUfDO', '', '', 'Bite Auswählen'),
(9, 'Test', 'Test', 'test@test.de', '$2y$10$l5D4jNjTFWYnG8x7/uHrJunjKOC5sD0S68XfpOCUBHOikcgXlGxve', '', '', 'Bite Auswählen'),
(10, 'Hallo', 'Welt', 'hallo@hallo.de', '$2y$10$Pj0JOpN2rg5x9NZxa/JKoe5htR5/Wm/K.1DSBq9IpWnc1Aj0BgEkK', 'Master', 'Vijay', 'Kino');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `reviewlist`
--

CREATE TABLE `reviewlist` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `film_titel` varchar(255) NOT NULL,
  `film_bewertung` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `reviewlist`
--

INSERT INTO `reviewlist` (`id`, `user_id`, `film_titel`, `film_bewertung`) VALUES
(1, 1, 'Avengers', 'Eine von der besten film die ich gesehen hab. ich werde gerne 9 von 10 Punkten bewerten. '),
(2, 2, 'Conjuring Teil 1 und 2', 'War so beängstigend. Warte auf das nächste Kapite.'),
(3, 3, 'Annabelle', 'Es war ok, aber im Vergleich zum Conjuring, gefiel mir das Zaubern am besten. '),
(4, 4, 'James Bond - Keine Zeit zu sterben', 'Habe den Höhepunkt nicht erwartet. war so toll '),
(19, NULL, 'TEST', 'ewrweafdx');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indizes für die Tabelle `reviewlist`
--
ALTER TABLE `reviewlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uer_id` (`user_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `members`
--
ALTER TABLE `members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `reviewlist`
--
ALTER TABLE `reviewlist`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `reviewlist`
--
ALTER TABLE `reviewlist`
  ADD CONSTRAINT `fremdschlüssel` FOREIGN KEY (`user_id`) REFERENCES `members` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
