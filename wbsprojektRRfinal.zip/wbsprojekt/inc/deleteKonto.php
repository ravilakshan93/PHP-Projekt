<?php
    session_start();
    require_once 'myDatenbank.inc.php';
    require_once 'functionen.inc.php';


    $id = $_SESSION['id'];

    if(!empty($id) ) {
    $sql = 'DELETE FROM members WHERE id = ?';
        $loginDaten = $datenbank->prepare($sql);
        $loginDaten->execute([$id]);
        ausLoggen();
        $_SESSION['nachricht'] = 'Konto wurde gelöscht.';
}

homepage('../index.php');
?>
