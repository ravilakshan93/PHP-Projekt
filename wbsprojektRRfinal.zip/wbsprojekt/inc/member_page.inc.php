<ul>
  <li>
    <a href="index.php?page=myKonto">Mein Konto</a>
  </li>
  <li>
    <a href="inc/ausloggen.php">Ausloggen</a>
  </li>
</ul>

<div>
  <p id="message">Eingeloggt als: <em><?= $_SESSION["angemeldet_member"] ?></em> </p>
</div>