<?php
    session_start();
    require_once "myDatenbank.inc.php";
    require_once "functionen.inc.php";

    $mail = $_POST["mail"];
    $password = $_POST["password"];

        if(!empty($mail) && !empty($password) )
        {
            $sql = "SELECT * FROM members WHERE email = ?";
            $loginDaten = $datenbank->prepare($sql);
            $loginDaten->execute([$mail]);
            $member = $loginDaten->fetch();
                if($member && password_verify($password, $member["passwort"]) )
                {
                    einLoggen($member["email"], $member["name"], $member["id"]);
                }
                else
                {
                $_SESSION["nachricht"] =  "Falsche E-Mail / Passwort  -
                                            Ihre Daten stimmen nicht überein. Bitte versuchen Sie es erneut";
                }
        }
        homepage("../index.php");
?>