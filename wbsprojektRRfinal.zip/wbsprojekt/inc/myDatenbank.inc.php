<?php
    $verweis = [PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING,];
    $datenbank = new PDO("mysql:host=localhost;dbname=wbsprojekt", "root", "", $verweis);      
    $datenbank->query('SET NAMES utf8');
?>


