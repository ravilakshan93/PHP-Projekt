<?php

  require_once 'myDatenbank.inc.php';
  require_once 'functionen.inc.php';

  session_start();

  if( !empty($_POST) ) 
  {
      $sql = 'INSERT INTO reviewlist(id, user_id, film_titel, film_bewertung)
                          VALUES(:id, :userid, :titel, :bewertung)';
    
      $loginDaten = $datenbank->prepare($sql);
      $loginDaten->execute($_POST);
    
      $_SESSION['nachricht'] = 'Eintrag wurde eingefügt<br />Vielen Dank';
      homepage('../index.php?page=bewertung');
  }

?>
