<div id="registerWrapper">
<h2>Bitte registrieren Sie hier und merken Sie Ihre Benutzerdaten</h2>
    <form action="inc/register.php" method="post" id="register">
        <input type="text" name="name" placeholder="Nachname eingeben" required />
            <input type="text" name="vorname" placeholder="Vorname eingeben" required />
			<input type="email" name="mail" placeholder="E-Mail eingeben" required />
			<input type="password" name="passwort" placeholder="Passwort eingeben" required />
        <fieldset style="padding-bottom:15px;" class="liebling">
            <legend>Ihre Bewertung</legend>
                <textarea name="filme" placeholder="Ihr Lieblings Film"></textarea>
                <textarea name="actor" placeholder="Ihr Lieblings Schauspieler/in"></textarea>

                <select name="choice" id="choice">
                    <option>Bite Auswählen</option>
                    <option>Kino</option>
                    <option>OTT</option>
                </select>
        </fieldset>
        <input class="register" type="submit" value="Konto anlegen" />
    </form>
</div>