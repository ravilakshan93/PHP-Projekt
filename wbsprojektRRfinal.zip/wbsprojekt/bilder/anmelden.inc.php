topLogo


  Cinema & OTT Anytime & Anywhere

socialMedia top

myslide1 myslide2 myslide3 myslide4 myslide1

  * Home <http://localhost/kurs/PROJEKT/wbsprojekt/index.php>
  * Cinema <http://localhost/kurs/PROJEKT/wbsprojekt/index.php?page=cinema>
  * OTT <http://localhost/kurs/PROJEKT/wbsprojekt/index.php?page=ott>
  * Kontakt
    <http://localhost/kurs/PROJEKT/wbsprojekt/index.php?page=kontakt>
  * Filmbewertung
    <http://localhost/kurs/PROJEKT/wbsprojekt/index.php?page=bewertung>


    Hier können Sie sich einloggen, um einen Film, den Sie kürzlich
    gesehen haben, zu bewerten. Wenn Sie kein Konto haben, können Sie
    sich kostenlos registrieren, um eine Bewertung abzugeben.


      Anmelden

Noch keinen Mitglied?Bitte Registrieren
<http://localhost/kurs/PROJEKT/wbsprojekt/index.php?page=new-member>

Loggen Sie heute noch ein

/


      © WBS PHP Abschluss Projekt - Oktober 2021 - Ravilakshan Ravikumar

  * Impressum

