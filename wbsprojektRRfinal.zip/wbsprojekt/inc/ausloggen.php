<?php
    session_start();
    require_once "functionen.inc.php";

    ausLoggen();
    $_SESSION["nachricht"] = "Sie wurden erfolgreich abgemeldet";
    homepage("../index.php");

    session_destroy();

?>