<div class="kontaktWrapper">
    <div class="uhr"></div>
        <h3 class="titel4">Wenn Sie Fragen haben, kontaktieren Sie uns bitte, indem Sie das Kontaktformular ausfüllen, und wir werden uns so schnell wie möglich mit Ihnen in Verbindung setzen</h3>
        <div id="uhr"></div>
            <form action="#" method="post" id="form">
                <div>
                    <label for="nachname">Nachname:</label>
                        <input type="text" id="nachname " name="nachname" placeholder="Name eingeben" />
                </div>

                <div>
                    <label for="vorname">Vorname:</label>
                        <input type="text" id="vorname" name="vorname"  placeholder="Vorname eingeben" />
                </div>

                <div>
                    <label for="ort">Wohnort:</label>
                        <input type="text" id="ort" placeholder="Wohnort eingeben" name="ort" />
                </div>

                <div>
                    <label for="str">Straße:</label>
                        <input type="text" id="str" placeholder="Straße eingeben" name="str"/>
                </div>

                <div>
                    <label for="plz">PLZ:</label>
                        <input type="text" id="plz" placeholder="PLZ eingeben" name="plz"/>
                </div>

                <div>
                    <label for="mail">E-Mail:</label>
                        <input type="email" id="mail" placeholder="E-Mail eingeben" name="email"/>
                </div>

                <div>
                    <label for="tel">Telefon:</label>
                        <input type="tel" id="tel" placeholder="Telefon eingeben" name="tel"/>
                </div>

                <input id="senden" type="submit" value="Abschicken"  />
                <input id="loeschen" type="reset"  value="Löschen" />
            </form>
</div>