<?php

    //Funktion für den Member wenn er falsche benutzerdaten eingegeben hat wird er automatik auf index seite landen
    function homepage($index){
        header("Location: " .$index);
        exit;
    }
    //Funktion für den Member zum einloggen

    function clean($memberEingabe, $encoding='UTF-8') {
        return htmlspecialchars(
                    strip_tags(trim($memberEingabe)),
                    ENT_QUOTES | ENT_HTML5, 
                    $encoding);
    }

    function einLoggen($mail, $membername, $id) {
        $_SESSION["angemeldet"] = $mail;
        $_SESSION["angemeldet_member"] = $membername;
        $_SESSION["id"] = $id;
    }


    //Funktion für den Member ob sich eingeloggt ist
    function istAngemeldet() {
    return isset($_SESSION["angemeldet"]);
    }


    function ausLoggen(){
        unset($_SESSION["angemeldet"]);
        unset($_SESSION["angemeldet_member"]);
        unset($_SESSION['id']);
    }

?>

