<?php
$sql = 'SELECT * FROM members WHERE email = ?';
$st = $datenbank->prepare($sql);
$st->execute([$_SESSION["angemeldet"]]);
$daten = $st->fetch();
?>

<div class="myKontoWrapper">
<article>
  <h2 class="header1" style="color:gold; text-align: center;"><?= clean($daten['name']) ?></h2>
    <div class="myKonto">
        <?php  ?>
        <form action="inc/deleteKonto.php" method="post" class="form2">
            <button class="edit" href="">Bearbeiten</a></button>
            <button type="submit" class="delete">Konto Löschen</button>
        </form>
    </div>
</article>
</div>
