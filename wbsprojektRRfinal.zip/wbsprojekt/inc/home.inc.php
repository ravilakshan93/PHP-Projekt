<div class="homeWrapper">
        <div id="homeText">
            <h2 class="titel1">Willkommen zu die Welt von Cinema & OTT!</h2>
                <p id="homeInfo">
                    Willkommen Filmfans Hier können Sie sich über die verschiedenen Filme auf verschiedenen Plattformen informieren. Filme, die sowohl in Kinos als auch auf OTT-Plattformen veröffentlicht werden. Auf dieser Seite können Sie sich als Mitglied registrieren, um Ihre Rezension und Bewertung für einen Film abzugeben, den Sie gesehen haben oder sehen werden.
                </p>

                <p id="homeInfo">
                    Es gibt viele Filme mit unterschiedlichen Genres und in unterschiedlichen Formaten. Beispiele für Filmgenres sind Thriller, Horror, Action, Komödie usw. Beispiele für Filmformate sind Schwarzweißfilme, Farbfilme, 3D-Filme, Animationsfilme und OTT. OTT steht kurz für Over-the-top media service
                </p>

                <p id="homeInfo">
                    OTT stands for (Over-the-top media service), and here are a variety of different types of platforms which includes Netflix, a common platform which is the most viewed platform on the world.Other examples includes, Disney+ Hotstar, Amazon Prime, Sony Liv und etc
                </p>
        </div>

        <div id="sideBar">
            <h3>Am häufigsten gesehen </h3>
                <section>
                    <span>Haus des geldes(OTT)</span>
                    <img src="./bilder/section1.png" alt="Haus des geldes" width="100" height="100">
                </section>
                <section>
                    <span>James Bond 007: Keine Zeit zu sterben</span>
                    <img src="./bilder/section2.png" alt="Haus des geldes" width="100" height="100">
                </section>
                <section>
                    <span>IT</span>
                    <img src="./bilder/section3.png" alt="Haus des geldes" width="100" height="100">
                </section>
        </div>
</div>
