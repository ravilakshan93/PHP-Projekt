<?php
    require_once "functionen.inc.php";
    require_once "myDatenbank.inc.php";

    $sql = 'SELECT * FROM reviewlist' ;
            
    $st = $datenbank->query($sql);
    $daten = $st->fetchAll();
    $count = $st->rowCount();

    /*
    if($count < 1) {
    echo 'Keine Einträge vorhanden';
    } else {
    echo '<p>'. $count.' Kommentare</p>';
    }
    var_dump(istAngemeldet());
    */
?>

<?php
    if(istAngemeldet()):  
?>
<div id=reviewWrapper>
<h2>Member Bewertungen</h2>
    <form action="inc/bewertung_eintrag.php" method="post" class="registrierung">
        <fieldset class="fieldset2">
            <h3 style="color:white">Geben Sie Ihr Bewertung für den Film oder Serie die gesehen haben.</h3>
                <input class="filmtitel" type="text" name="titel" placeholder="Film Titel eingeben" required />
                <textarea name="bewertung" placeholder="Film bewerten(Rating)"></textarea>
                <input class="filmtitel" type="hidden" name="memberid" value="<?= $_SESSION['id'] ?>" />
        </fieldset>

            <?php if
                (istAngemeldet()): 
            ?>
                <input style="padding:10px; color: green; font-size:20px; cursor: pointer; border-radius:20px; margin-bottom: 15px;" class="jetztBewerten" type="submit" value="Film Bewerten" />
            <?php else: ?>
                <strong>Member Review</strong>
            <?php endif; ?>
    </form>
    <!-- ++++++++++++++++++++++++++++++++++++++++++++ -->
    <article id="neuBewertung">
    <h2>Bewertungen von anderen Member</h2>

    <?php
        $sql = 'SELECT * FROM reviewlist INNER JOIN members 
                    ON
                    reviewlist.user_id = members.id';
        $st = $datenbank->query($sql);
        $daten = $st->fetchAll();
        $count = $st->rowCount();
        
    ?>
    <?php
        foreach($daten AS $review): 
    ?>
        <section class="bewertungChronik">
            <h3 class="header">Film Name: <?= clean($review['film_titel']) ?> </h3>
                <p class="myName">Geschrieben von: <?= clean($review['name']) ?></p>
                <p class="myReview">Bewertung: <?= clean($review['film_bewertung']) ?></p>
        </section>

    <?php
         endforeach;
        else: 
    ?>
    </article>


<!--Vor Log in / Register-->

<div id="bewertungWrapper">
    <div>
        <h2>
            Hier können Sie sich einloggen, um einen Film, den Sie kürzlich gesehen haben, zu bewerten. Wenn Sie kein Konto haben, können Sie sich kostenlos registrieren, um eine Bewertung abzugeben. 
        </h2>
    </div>

    <div id="formWrapper">
        <h3>Anmelden</h3> 
            <form action="inc/anmelden.php" method="post">
                <div id="email">
                    <input type="text" name="mail" placeholder="E-Mail">
                </div>
                <div id="email">
                    <input type="password" name="password" placeholder="Passwort">
                </div>
                <input type="submit" value="Einloggen">
            </form>
            <p class="reg">Noch keinen Mitglied?<a href="index.php?page=new"> Registrieren</a></p>
    </div>

    <div>
        <img src="./bilder/bewertung_zeigen.jpg" alt="Loggen Sie heute noch ein">
    </div>
        <?php endif;
        ?>
</div>
