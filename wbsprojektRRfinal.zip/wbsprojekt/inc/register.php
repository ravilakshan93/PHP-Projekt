<?php
session_start();

require_once "myDatenbank.inc.php";
require_once "functionen.inc.php";

    $name = clean($_POST['name']);
    $vorname = clean($_POST['vorname']);
    $mail = clean($_POST['mail']);
    $passwort = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $filme = clean($_POST['filme']) ?? '';
    $actor = clean($_POST['actor']) ?? '';
    $choice = clean($_POST['choice']) ?? '';

    $mailExist = 'SELECT * FROM members WHERE email = ?';
    $loginDaten = $datenbank->prepare($mailExist);
    $loginDaten->execute([$mail]);
    $member = $loginDaten->fetch();

  if(!($member))
  {
    $sql = "INSERT INTO members(name,vorname,email,passwort,lieblings_filme,lieblings_Schauspieler_in,kino_oder_ott) 
            VALUES(?,?,?,?,?,?,?)";
                            
    $loginDaten = $datenbank->prepare($sql); 
    $loginDaten->execute([$name,$vorname,$mail,$passwort, $filme, $actor, $choice]);

    $_SESSION['nachricht'] = 'Registrierung erfolgreich, Bitte sich einloggen.';
    homepage('../index.php');
  } 
  else 
  {
    $_SESSION['nachricht'] = 'Die E-Mail existiert!<br />Bitte andere E-Mail eingeben';
    homepage('../index.php?page=new');
  }
?>